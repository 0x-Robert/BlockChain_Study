const RES4 = artifacts.require("RES4");

module.exports = function(deployer) {
  deployer.deploy(RES4);
};
